// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyAlaYKgPPGX6tgV_tXIDP1Ge2ebsd9_ygI",
    authDomain: "examenlmsg-423f2.firebaseapp.com",
    projectId: "examenlmsg-423f2",
    storageBucket: "examenlmsg-423f2.appspot.com",
    messagingSenderId: "275269309689",
    appId: "1:275269309689:web:ce383de9a8a8f71f72be28",
    measurementId: "G-B01C3PRQWZ"
};

// Inicializa Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();


// Referencia al formulario y lista de estudiantes
const addStudentForm = document.getElementById('add-student-form');
const studentsList = document.getElementById('students-list');
const editStudentForm = document.getElementById('edit-student-form');

// Función para agregar un estudiante
addStudentForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const surname = document.getElementById('surname').value;
    const dni = document.getElementById('dni').value;
    const phone = document.getElementById('phone').value;

    if (!/^[0-9]+$/.test(phone)) {
        alert('Por favor, ingrese solo números en el campo de teléfono');
        return;
    }

    db.collection('students').add({
        name: name,
        surname: surname,
        dni: dni,
        phone: phone,
        attendance: false
    }).then(() => {
        addStudentForm.reset();
        fetchStudents();
    }).catch(error => console.error('Error adding document: ', error));
});

// Función para obtener la lista de estudiantes
function fetchStudents() {
    studentsList.innerHTML = '';
    db.collection('students').get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            const student = doc.data();
            const avatarUrl = `https://api.multiavatar.com/${student.name}.png`;
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><img src="${avatarUrl}" alt="Foto" class="avatar" onerror="this.onerror=null; this.src='default-avatar.png';"></td>
                <td>${student.name}</td>
                <td>${student.surname}</td>
                <td>${student.dni}</td>
                <td>${student.phone}</td>
                <td>
                    <span class="${student.attendance ? 'attendance-present' : 'attendance-absent'}">
                        ${student.attendance ? '<i class="fas fa-check"></i>' : '<i class="fas fa-times"></i>'}
                    </span>
                </td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-primary" onclick="editStudent('${doc.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="confirmToggleAttendance('${doc.id}', ${student.attendance})">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="confirmDeleteStudent('${doc.id}')">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
            studentsList.appendChild(tr);
        });
    });
}

// Función para editar un estudiante
function editStudent(id) {
    const studentRef = db.collection('students').doc(id);
    studentRef.get().then((doc) => {
        if (doc.exists) {
            const student = doc.data();
            document.getElementById('edit-student-id').value = id;
            document.getElementById('edit-name').value = student.name;
            document.getElementById('edit-surname').value = student.surname;
            document.getElementById('edit-dni').value = student.dni;
            document.getElementById('edit-phone').value = student.phone;
            $('#editStudentModal').modal('show');
        }
    });
}

// Función para guardar los cambios de un estudiante
editStudentForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const id = document.getElementById('edit-student-id').value;
    const name = document.getElementById('edit-name').value;
    const surname = document.getElementById('edit-surname').value;
    const dni = document.getElementById('edit-dni').value;
    const phone = document.getElementById('edit-phone').value;

    db.collection('students').doc(id).update({
        name: name,
        surname: surname,
        dni: dni,
        phone: phone
    }).then(() => {
        $('#editStudentModal').modal('hide');
        fetchStudents();
    }).catch(error => console.error('Error updating document: ', error));
});

// Función para confirmar el cambio de estado de asistencia
function confirmToggleAttendance(id, currentStatus) {
    if (confirm('¿Estás seguro de que deseas cambiar el estado de asistencia?')) {
        toggleAttendance(id, currentStatus);
    }
}

// Función para cambiar el estado de asistencia
function toggleAttendance(id, currentStatus) {
    db.collection('students').doc(id).update({
        attendance: !currentStatus
    }).then(() => fetchStudents());
}

// Función para confirmar la eliminación de un estudiante
function confirmDeleteStudent(id) {
    if (confirm('¿Estás seguro de que deseas eliminar este estudiante?')) {
        deleteStudent(id);
    }
}

// Función para eliminar un estudiante
function deleteStudent(id) {
    db.collection('students').doc(id).delete().then(() => fetchStudents());
}

// Obtener estudiantes al cargar la página
window.onload = fetchStudents;
